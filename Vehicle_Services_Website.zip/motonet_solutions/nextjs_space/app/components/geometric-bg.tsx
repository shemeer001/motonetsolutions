'use client';

import { motion } from 'framer-motion';

export default function GeometricBg() {
  const triangles = [
    { top: '5%', right: '-2%', size: 120, rotate: 15, delay: 0, color: 'rgba(0,188,212,0.15)' },
    { top: '10%', right: '3%', size: 80, rotate: 45, delay: 0.5, color: 'rgba(79,195,247,0.12)' },
    { top: '2%', right: '8%', size: 60, rotate: -15, delay: 1, color: 'rgba(0,188,212,0.1)' },
    { bottom: '15%', left: '-3%', size: 100, rotate: 30, delay: 0.3, color: 'rgba(79,195,247,0.1)' },
    { bottom: '5%', left: '5%', size: 70, rotate: 60, delay: 0.8, color: 'rgba(0,188,212,0.08)' },
    { top: '40%', right: '-1%', size: 90, rotate: -30, delay: 1.2, color: 'rgba(0,188,212,0.1)' },
    { top: '60%', left: '-2%', size: 110, rotate: 20, delay: 0.6, color: 'rgba(79,195,247,0.08)' },
  ];

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {triangles?.map((t: any, i: number) => (
        <motion.div
          key={i}
          className="absolute"
          style={{
            top: t?.top,
            right: t?.right,
            bottom: t?.bottom,
            left: t?.left,
            width: t?.size ?? 80,
            height: t?.size ?? 80,
          }}
          animate={{
            y: [0, -20, 0],
            rotate: [(t?.rotate ?? 0), (t?.rotate ?? 0) + 10, (t?.rotate ?? 0)],
            opacity: [0.5, 0.8, 0.5],
          }}
          transition={{
            duration: 6 + i * 0.5,
            delay: t?.delay ?? 0,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          <svg viewBox="0 0 100 100" className="w-full h-full">
            <polygon
              points="50,5 95,95 5,95"
              fill={t?.color ?? 'rgba(0,188,212,0.1)'}
            />
          </svg>
        </motion.div>
      ))}
    </div>
  );
}
